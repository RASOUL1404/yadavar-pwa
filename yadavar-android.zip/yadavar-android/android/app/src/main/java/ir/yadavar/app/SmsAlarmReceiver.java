package ir.yadavar.app;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.os.Build;
import android.telephony.SmsManager;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/** در موعد هر رویداد: ارسال پیامک به گیرنده‌ها و نمایش اعلان. */
public class SmsAlarmReceiver extends BroadcastReceiver {
    static final String CHANNEL = "yadavar_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        int idx = intent.getIntExtra("idx", -1);
        JSONArray ev = Sched.load(context);
        if (idx < 0 || idx >= ev.length()) return;
        JSONObject o = ev.optJSONObject(idx);
        if (o == null) return;

        String title = o.optString("title", "یادآور");
        String text = o.optString("text", "");
        String msg = o.optString("msg", title);
        JSONArray phones = o.optJSONArray("phones");

        int sent = 0;
        int total = phones == null ? 0 : phones.length();
        if (total > 0 && hasSms(context)) {
            for (int i = 0; i < total; i++) {
                if (sendSms(context, phones.optString(i), msg)) sent++;
            }
        }

        String body = text;
        if (total > 0) {
            String st = sent + " از " + total + " پیامک ارسال شد";
            body = body.isEmpty() ? st : body + "\n" + st;
        }
        notify(context, idx, title, body);
    }

    static boolean hasSms(Context c) {
        return ContextCompat.checkSelfPermission(c, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean sendSms(Context c, String phone, String message) {
        try {
            if (phone == null || phone.isEmpty()) return false;
            SmsManager sm = Build.VERSION.SDK_INT >= 31
                    ? c.getSystemService(SmsManager.class)
                    : SmsManager.getDefault();
            ArrayList<String> parts = sm.divideMessage(message);
            sm.sendMultipartTextMessage(phone, null, parts, null, null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static void notify(Context c, int id, String title, String body) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "یادآورها", NotificationManager.IMPORTANCE_HIGH);
                ch.enableVibration(true);
                ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), null);
                nm.createNotificationChannel(ch);
            }
            Intent open = new Intent(c, MainActivity.class);
            open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pi = PendingIntent.getActivity(c, 0, open, flags);

            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            if (Build.VERSION.SDK_INT >= 33
                    && ContextCompat.checkSelfPermission(c, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            NotificationManagerCompat.from(c).notify(1000 + id, b.build());
        } catch (Exception ignored) {
        }
    }
}
