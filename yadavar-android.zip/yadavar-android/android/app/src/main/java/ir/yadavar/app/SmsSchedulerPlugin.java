package ir.yadavar.app;

import android.Manifest;
import android.os.Build;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

@CapacitorPlugin(
        name = "SmsScheduler",
        permissions = {
                @Permission(alias = "sms", strings = {Manifest.permission.SEND_SMS}),
                @Permission(alias = "notif", strings = {"android.permission.POST_NOTIFICATIONS"})
        }
)
public class SmsSchedulerPlugin extends Plugin {

    @PluginMethod
    public void replaceAll(PluginCall call) {
        try {
            JSArray arr = call.getArray("events");
            JSONArray ev = arr == null ? new JSONArray() : arr;
            int n = Sched.replaceAll(getContext(), ev);
            JSObject r = new JSObject();
            r.put("scheduled", n);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("replaceAll failed: " + e.getMessage());
        }
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject r = new JSObject();
        long now = System.currentTimeMillis();
        JSONArray ev = Sched.load(getContext());
        int n = 0;
        for (int i = 0; i < ev.length(); i++) {
            if (ev.optJSONObject(i) != null && ev.optJSONObject(i).optLong("at", 0) > now) n++;
        }
        r.put("scheduled", n);
        r.put("exact", Sched.canExact(getContext()));
        r.put("sms", SmsAlarmReceiver.hasSms(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void sendNow(PluginCall call) {
        String phone = call.getString("phone", "");
        String message = call.getString("message", "");
        JSObject r = new JSObject();
        boolean ok = SmsAlarmReceiver.hasSms(getContext()) && SmsAlarmReceiver.sendSms(getContext(), phone, message);
        r.put("sent", ok);
        call.resolve(r);
    }

    @PluginMethod
    public void requestAll(PluginCall call) {
        List<String> aliases = new ArrayList<>();
        aliases.add("sms");
        if (Build.VERSION.SDK_INT >= 33) aliases.add("notif");
        requestPermissionForAliases(aliases.toArray(new String[0]), call, "permsDone");
    }

    @PermissionCallback
    private void permsDone(PluginCall call) {
        JSObject r = new JSObject();
        r.put("sms", SmsAlarmReceiver.hasSms(getContext()) ? "granted" : "denied");
        call.resolve(r);
    }
}
