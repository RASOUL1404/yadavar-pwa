package ir.yadavar.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/** ذخیره و زمان‌بندی رویدادها با AlarmManager. */
public class Sched {
    static final String PREFS = "yadavar";
    static final String KEY = "events";

    static JSONArray load(Context c) {
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
            return new JSONArray(s);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static PendingIntent pending(Context c, int idx) {
        Intent i = new Intent(c, SmsAlarmReceiver.class);
        i.setAction("ir.yadavar.app.FIRE");
        i.setData(Uri.parse("yadavar://event/" + idx));
        i.putExtra("idx", idx);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, idx, i, flags);
    }

    static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        JSONArray old = load(c);
        for (int i = 0; i < old.length(); i++) {
            am.cancel(pending(c, i));
        }
    }

    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am.canScheduleExactAlarms();
    }

    static int armAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        JSONArray ev = load(c);
        long now = System.currentTimeMillis();
        int n = 0;
        boolean exact = canExact(c);
        for (int i = 0; i < ev.length(); i++) {
            JSONObject o = ev.optJSONObject(i);
            if (o == null) continue;
            long at = o.optLong("at", 0);
            if (at <= now) continue;
            PendingIntent pi = pending(c, i);
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
                }
                n++;
            } catch (SecurityException e) {
                am.set(AlarmManager.RTC_WAKEUP, at, pi);
                n++;
            }
        }
        return n;
    }

    static int replaceAll(Context c, JSONArray ev) {
        cancelAll(c);
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        sp.edit().putString(KEY, ev.toString()).apply();
        return armAll(c);
    }
}
